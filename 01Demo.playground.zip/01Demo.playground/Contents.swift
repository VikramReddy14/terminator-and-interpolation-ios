import UIKit

var greeting = "Hello, playground"
print("Hii",10,12.25)

var programmingLanguage = "Swift"
var name = "Ajay"
var grade = "B"
var name1 = "Vikram"
var grade1 = 90
print("Hello,\(name)! You got the \(grade) in ios course.")

var age = 24

print("Your age is \(age) and when tripled your age will be \(age*3)")

print("""
      Hello
      World!
      I'm
      Vikram
""")

print ("Hello All,\rWelcome to Swift programming")

//let is a constant
//explicit declaration
let  welcomeMessage : String = "Hello!"
   print(welcomeMessage , "All")
print("Welcome to Swift Programming")
print("Fall 2021")
print("*************")
print("Welcome to Swift Programming" , terminator : "-" )
print("Spring 2022")
print("Hi \(name1)" , terminator : "-" )
print("You got \(grade1)% in ios course.")
print("The list of numbers are ")
print(1,2,3,4,5,6)
print("The new pattern is", terminator : " : ")
print(1,2,3,4,5,6, separator: "-")

